// Weichao Qiu @ 2018
#include "CamSensorActor.h"


// Sets default values
ACamSensorActor::ACamSensorActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ACamSensorActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ACamSensorActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

