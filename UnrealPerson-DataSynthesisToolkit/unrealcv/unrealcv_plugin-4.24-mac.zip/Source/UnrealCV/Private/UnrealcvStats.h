// Weichao Qiu @ 2018
#pragma once
#include "Runtime/Core/Public/Stats/Stats.h"
DECLARE_STATS_GROUP(TEXT("UnrealCV"), STATGROUP_UnrealCV, STATCAT_Advanced);