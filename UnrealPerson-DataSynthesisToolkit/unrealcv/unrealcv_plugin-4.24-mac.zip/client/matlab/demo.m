% Run the program
clearvars;
response = request('vget /viewmode'); % The connection
response = request('vget ');
